# =====================================================================
#  HAULIST AUTO-UPDATE  (double-click "Update Haulist.bat")
#  1. Saves ONE backup of the version that's live now
#  2. Copies in the newest Haulist-web*.zip from the "updates" folder or Downloads
#     (never touches config.js)
#  Lives INSIDE Documents\Portfolio\Haulist\haulist (your repo folder)
#  3. Uploads to GitHub -> live in about 1 minute
#  Undo: double-click "Undo Last Update.bat"
# =====================================================================
param([switch]$Rollback)

$RepoDir   = $PSScriptRoot                          # the folder this script is in = your repo
$ZipDirs   = @("$RepoDir\updates", "$env:USERPROFILE\Downloads")   # where new versions are looked for
$BackupDir = "$RepoDir\_last_backup"                # 1 backup (not uploaded to GitHub)
$Files = 'index.html','manifest.json','sw.js','icon.svg','icon-192.png','icon-512.png'   # config.js is never replaced
function Say($m, $c = 'Cyan') { Write-Host $m -ForegroundColor $c }
function Stop-With($m) { Say $m Red; Read-Host "Press Enter to close"; exit 1 }

if (!(Get-Command git -ErrorAction SilentlyContinue)) { Stop-With "Git isn't installed. Get it from git-scm.com, then try again." }
if (!(Test-Path "$RepoDir\.git")) { Stop-With "This script must be inside your repo folder: Documents\Portfolio\Haulist\haulist" }
Set-Location $RepoDir
git pull --quiet

# ---------- UNDO: put the backup back ----------
if ($Rollback) {
  if (!(Test-Path $BackupDir)) { Stop-With "No backup found yet." }
  Copy-Item "$BackupDir\*" $RepoDir -Force
  git add -A
  git commit -m "Undo last update (restore backup)" | Out-Null
  git push
  Say "Restored the previous version. Live in about 1 minute." Green
  Read-Host "Press Enter to close"; exit
}

# keep helper files off the website
if (!(Test-Path .gitignore) -or !((Get-Content .gitignore -Raw) -match '_last_backup')) {
  Add-Content .gitignore "_last_backup/`nupdates/`n*.bat`n*.ps1"
}

# ---------- UPDATE ----------
$zip = $ZipDirs | Where-Object { Test-Path $_ } | ForEach-Object { Get-ChildItem $_ -Filter 'Haulist-web*.zip' } |
       Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (!$zip) { Stop-With "No Haulist-web.zip found in the updates folder or Downloads" }
Say "Using $($zip.Name)  (downloaded $($zip.LastWriteTime))"

# 1. one backup of what's live now (replaces the previous backup)
if (Test-Path $BackupDir) { Remove-Item $BackupDir -Recurse -Force }
New-Item $BackupDir -ItemType Directory | Out-Null
foreach ($f in $Files) { if (Test-Path $f) { Copy-Item $f $BackupDir } }
Say "Backup saved to $BackupDir"

# 2. unpack and copy the new files (skips config.js so your keys stay)
$tmp = Join-Path $env:TEMP "haulist_update"
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
Expand-Archive $zip.FullName $tmp
$copied = 0
foreach ($f in $Files) { if (Test-Path "$tmp\$f") { Copy-Item "$tmp\$f" $RepoDir -Force; $copied++ } }
if ($copied -eq 0) { Stop-With "That zip had no Haulist files in it." }

# 3. safety check on your keys
if (!(Test-Path config.js) -or ((Get-Content config.js -Raw) -match 'PASTE-')) {
  Say "Warning: config.js is missing your Supabase keys. The site will open in Demo mode." Yellow
}

# 4. publish
$ver = (Select-String -Path sw.js -Pattern 'haulist-v[\d\.]+').Matches.Value
git add -A
git commit -m "Update Haulist ($ver)" | Out-Null
git push
Say "Done! $ver goes live in about 1 minute." Green
Read-Host "Press Enter to close"
